//
//  atendimento.m
//  CVP - iOS
//
//  Created by halverny on 12/29/13.
//  Copyright (c) 2013 Clinica Vicente de Paula. All rights reserved.
//

#import "atendimento.h"

@implementation atendimento

@end
