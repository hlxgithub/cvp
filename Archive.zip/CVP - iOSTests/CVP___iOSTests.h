//
//  CVP___iOSTests.h
//  CVP - iOSTests
//
//  Created by halverny on 12/29/13.
//  Copyright (c) 2013 Clinica Vicente de Paula. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface CVP___iOSTests : SenTestCase

@end
