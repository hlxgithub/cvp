//
//  DETALHEATENDIMENTOViewController.h
//  CVP - iOS
//
//  Created by halverny on 3/4/14.
//  Copyright (c) 2014 Clinica Vicente de Paula. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DETALHEATENDIMENTOViewController : UIViewController

@property (weak, nonatomic) IBOutlet UILabel *characterLabel;

@property int characterNumber;
@property (strong, nonatomic) NSString * characterName;

@end
