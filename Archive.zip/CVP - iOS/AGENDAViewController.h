//
//  AGENDAViewController.h
//  CVP - iOS
//
//  Created by halverny on 3/4/14.
//  Copyright (c) 2014 Clinica Vicente de Paula. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AGENDAViewController : UITableViewController

@property(nonatomic, strong) NSMutableArray * horasList;
@property(nonatomic, strong) NSMutableArray * nomepacientesList;
@property(nonatomic, strong) NSMutableArray * atendimentoList;
@property (nonatomic, strong) NSMutableArray * json;
@property (strong, nonatomic) NSDictionary * atendimentosArray;

@end

