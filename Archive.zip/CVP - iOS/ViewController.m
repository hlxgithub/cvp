//
//  ViewController.m
//  CVP - iOS
//
//  Created by halverny on 12/29/13.
//  Copyright (c) 2013 Clinica Vicente de Paula. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController
@synthesize json, dentistasArray;

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}

-(IBAction)enterCredentials
{
    
    NSMutableString *urlString = [NSMutableString stringWithFormat:@"http://www.halvernyx.com.br/php/logincvp.php"];
    
     [urlString appendString:[NSString stringWithFormat:@"?%@=%@", @"user_name", userNameField.text]];
     [urlString appendString:[NSString stringWithFormat:@"&%@=%@", @"password", passwordField.text]];
    [urlString appendString:[NSString stringWithFormat:@"&%@=%@",
         @"key", @"cronos"]];
    [urlString setString:[urlString stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding]];
    
    NSURL *url = [NSURL URLWithString:urlString];
    
    NSData *jsonData = [NSData dataWithContentsOfURL:url];
    
    id jsonObjects = [NSJSONSerialization JSONObjectWithData:jsonData options:NSJSONReadingMutableContainers error:nil];
    NSArray *keys = [jsonObjects allKeys];
    
    NSMutableString *CD = [NSMutableString stringWithFormat:@"0"];
    NSMutableString *NOMEDENTISTA = [NSMutableString stringWithFormat:@""];
    NSMutableString *ABREVIACAO = [NSMutableString stringWithFormat:@""];
    
    // values in foreach loop
    for (NSString *key in keys) {
        NSLog(@"%@ is %@",key, [jsonObjects objectForKey:key]);
        CD=[jsonObjects objectForKey:@"CODIGO"];
        NOMEDENTISTA=[jsonObjects objectForKey:@"NOME"];
        ABREVIACAO=[jsonObjects objectForKey:@"ABREVIACAO"];
    }
    
    if ( [CD isEqualToString:@"0"] )
    {
       UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Senha Inválida" message:@"Erro nas credenciais de acesso!" delegate:self cancelButtonTitle:@"Voltar" otherButtonTitles:nil];
        [alert show];
    }
    else
    {
        
    }

}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
