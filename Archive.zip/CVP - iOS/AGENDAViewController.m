//
//  AGENDAViewController.m
//  CVP - iOS
//
//  Created by halverny on 3/4/14.
//  Copyright (c) 2014 Clinica Vicente de Paula. All rights reserved.
//

#import "AGENDAViewController.h"
#import "DETALHEATENDIMENTOViewController.h"

@interface AGENDAViewController ()

@end

@implementation AGENDAViewController
@synthesize horasList, nomepacientesList;

- (id)initWithStyle:(UITableViewStyle)style
{
    self = [super initWithStyle:style];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
NSMutableString *urlString = [NSMutableString stringWithFormat:@"http://www.halvernyx.com.br/php/retornaagenda.php"];

[urlString appendString:[NSString stringWithFormat:@"?%@=%@", @"user_name", @"RANIERE" ]];
    
[urlString appendString:[NSString stringWithFormat:@"&%@=%@", @"password", @"123"]];
    
[urlString appendString:[NSString stringWithFormat:@"&%@=%@", @"medico", @"1"]];
    
[urlString appendString:[NSString stringWithFormat:@"&%@=%@", @"dia", @"2014-03-05"]];
    
[urlString appendString:[NSString stringWithFormat:@"&%@=%@", @"key", @"cronos"]];
   
[urlString setString:[urlString stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding]];

NSURL *url = [NSURL URLWithString:urlString];

NSData *jsonData = [NSData dataWithContentsOfURL:url];

NSDictionary *jsonObjects = [NSJSONSerialization JSONObjectWithData:jsonData options:0 error:nil];
    
horasList = [[NSMutableArray alloc]initWithObjects:nil];
nomepacientesList  = [[NSMutableArray alloc]initWithObjects:nil];
    
    for (NSDictionary *ate in jsonObjects){
        
        NSString *teste = [ate objectForKey:@"HORA"];
        NSString *pac = [ate objectForKey:@"NOME"];
    //    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Senha Inválida" message:@"Erro nas credenciais de acesso!" delegate:self cancelButtonTitle:teste otherButtonTitles:nil];
     //   [alert show];
        
        [horasList addObject:teste];
        [nomepacientesList addObject:pac];
    
    }

 //_atendimentosArray =[NSJSONSerialization JSONObjectWithData:jsonData options:0 error:nil];
    
     
 //   NSMutableArray *ke =[jsonObjects objectForKey:@"MEDICO"];
 //   _atendimentosArray = [jsonObjects objectForKey:@"MEDICO"];
/*

NSMutableString *CD = [NSMutableString stringWithFormat:@"0"];
NSMutableString *NOMEDENTISTA = [NSMutableString stringWithFormat:@""];
NSMutableString *ABREVIACAO = [NSMutableString stringWithFormat:@""];

    
// values in foreach loop
for (NSString *key in keys) {
    NSLog(@"%@ is %@",key, [jsonObjects objectForKey:key]);
}

if ( [CD isEqualToString:@"0"] )
{
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Senha Inválida" message:@"Erro nas credenciais de acesso!" delegate:self cancelButtonTitle:@"Voltar" otherButtonTitles:nil];
    [alert show];
}
else
{
    
}
*/
    

    self.title = @"Table Test";
   
}


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{

    // Return the number of sections.
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    // Return the number of rows in the section.
    return horasList.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier forIndexPath:indexPath];
    
    if(cell == nil){
        cell=[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
    }
    
    cell.textLabel.text=[horasList objectAtIndex:indexPath.row];
    cell.detailTextLabel.text= [nomepacientesList objectAtIndex:indexPath.row];
    cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    
    return cell;
}

/*
// Override to support conditional editing of the table view.
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Return NO if you do not want the specified item to be editable.
    return YES;
}
*/

/*
// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        // Delete the row from the data source
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
    }   
    else if (editingStyle == UITableViewCellEditingStyleInsert) {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
    }   
}
*/

/*
// Override to support rearranging the table view.
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath
{
}
*/

/*
// Override to support conditional rearranging of the table view.
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Return NO if you do not want the item to be re-orderable.
    return YES;
}
*/


- (void) prepareForSegue:(UIStoryboardSegue *)segue
    sender:(id)sender
{
    DETALHEATENDIMENTOViewController * DVC = [[DETALHEATENDIMENTOViewController alloc]init];
    
    DVC = [segue destinationViewController];
    
    NSIndexPath * path = [self.tableView indexPathForSelectedRow];
    
    NSString * theCharacter = [horasList objectAtIndex:path.row];
    
    DVC.characterNumber = path.row;
    DVC.characterName = theCharacter;
}
/*
#pragma mark - Table view delegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Navigation logic may go here. Create and push another view controller.

     DETALHEATENDIMENTOViewController * DVC = [[DETALHEATENDIMENTOViewController alloc] init];
    
    DVC.characterName = [characterList objectAtIndex:indexPath.row];
    DVC.characterNumber = [indexPath row];
     // ...
     // Pass the selected object to the new view controller.
     [self.navigationController pushViewController:DVC animated:YES];
}
 */
@end
